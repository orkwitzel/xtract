xtract sample archive.

Everything under here came out of one file.
